<?php
if ( ( is_home() && 'mh_full_width_page' === get_theme_mod( 'mharty_index_page_sidebar', 'mh_left_sidebar' ) ) ||
  ( ( is_archive() || is_search() || is_404() ) && 'mh_full_width_page' === get_theme_mod( 'mharty_archive_page_sidebar', 'mh_left_sidebar' ) ) ||
  ( is_page() && 'mh_full_width_page' === get_theme_mod( 'mharty_pages_sidebar', 'mh_default_sidebar' ) ) ||
  ( is_single() && 'mh_full_width_page' === get_theme_mod( 'mharty_posts_sidebar', 'mh_default_sidebar' ) ) ||
  ( is_singular( 'project' ) && 'mh_full_width_page' === get_theme_mod( 'mharty_projects_sidebar', 'mh_default_sidebar' ) ) ||
  ( ( class_exists( 'woocommerce', false ) && is_product() ) && 'mh_full_width_page' === get_theme_mod( 'mharty_products_sidebar', 'mh_default_sidebar' ) ) ||
  ( (
      ( is_single() && 'mh_default_sidebar' === get_theme_mod( 'mharty_posts_sidebar', 'mh_default_sidebar' ) ) ||
      ( is_page() && 'mh_default_sidebar' === get_theme_mod( 'mharty_pages_sidebar', 'mh_default_sidebar' ) ) ||
      ( is_singular( 'project' ) && 'mh_default_sidebar' === get_theme_mod( 'mharty_projects_sidebar', 'mh_default_sidebar' ) ) ||
      ( ( class_exists( 'woocommerce', false ) && is_product() ) && 'mh_default_sidebar' === get_theme_mod( 'mharty_products_sidebar', 'mh_default_sidebar' ) ) )
      && 'mh_full_width_page' === get_post_meta( get_queried_object_id(), '_mhc_page_layout', true ) 
  )  ||
  mh_composer_is_active( get_queried_object_id() )
  ) return;

  if ( is_active_sidebar( 'sidebar-1' ) ): ?>
<div id="sidebar">
  <?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
<!-- end #sidebar -->
<?php endif; ?>