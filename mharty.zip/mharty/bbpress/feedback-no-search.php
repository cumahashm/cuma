<?php

/**
 * No Search Results Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

	<h4><?php _e( 'No search results were found here!', 'bbpress' ); ?></h4>
    <p>
        <a class="btn btn-default" href="#" onclick="javascript: window.history.back();return false;"><?php _e("Go back", "bbpress");?></a>
    </p>
