<?php do_action('mh_after_content'); ?>
<?php if ( is_page_template( 'page-template-blank.php' ) || (is_single() && 'mh_post_blank' === get_post_meta( get_the_ID(), '_mhc_post_custom_template', true ) ) ): ?>
	<footer id="main-footer" style="display:none;">
		<?php if ( '' !== ( $mharty_cr_notice = get_theme_mod( 'cr_notice', '' ) ) ) { echo  '<div class="mh-copyrights">' . mh_sanitize_text_input( $mharty_cr_notice ) . '</div>';} ?>
		<div class="mh_cr"><?php mh_wp_kses( printf( __( 'Powered by %1$s | %2$s', 'mharty' ), '<a href="https://mharty.com" title="'. esc_html__( 'Premium RTL Wordpress Theme', 'mharty' ) .'">'. esc_html__( 'Mharty', 'mharty' ) .'</a>', '<a href="https://wordpress.org">'. esc_html__( 'WordPress', 'mharty' ) .'</a>' ) );?></div>
	</footer>
	
<?php else: ?>
	<footer id="main-footer">
		<?php get_sidebar( 'footer' ); ?>
		
		<?php if ( has_nav_menu( 'footer-menu' ) ) : ?>
			<div id="mh-footer-nav">
				<div class="container">
					<?php
						wp_nav_menu( array(
							'theme_location' => 'footer-menu',
							'depth'          => '1',
							'menu_class'     => 'bottom-nav',
							'container'      => '',
							'fallback_cb'    => '',
							'walker' => new mharty_walker,
						) );
					?>
				</div>
			</div> <!-- #mh-footer-nav -->
		<?php endif; ?>
		
		<div id="footer-bottom">
			<div class="container clearfix">
				<?php if ( '1' === get_theme_mod( 'show_footer_social_icons', '0' ) ) {
					$colorclass = '';
					if ( 'light' === get_theme_mod( 'footer_social_icons_color', 'dark' ) )
					$colorclass = ' mh-social-light-color';
					if ( 'color' === get_theme_mod( 'footer_social_icons_color', 'dark' ) )
					$colorclass = ' mh-social-default-color';
					echo '<div class="social-icons-wrapper'.$colorclass.'">';
						get_template_part( 'includes/social_icons', 'footer' );
					echo '</div>';
					}?>
				
				<div id="footer-info">
					<div class="mh-copyrights">
						<?php $mharty_cr_notice = '';
							  $mharty_cr_notice = '' !== get_theme_mod( 'cr_notice', '' ) ? mh_sanitize_text_input( get_theme_mod( 'cr_notice', '' ) ) : '&copy; ' . date( 'Y' ) . ' <a href="' . esc_html( get_bloginfo( 'url' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
								$footer_cr_output = sprintf('%1$s%2$s%3$s',					
								$mharty_cr_notice,
								'' !== $mharty_cr_notice && true === get_theme_mod( 'mharty_show_cr', true) ? ' | ' : '',
								true === get_theme_mod( 'mharty_show_cr', true)	?
										sprintf('<span%4$s>%1$s <a href="https://mharty.com" title="%2$s">%3$s</a></span>',
											esc_html__( 'Powered by', 'mharty' ),
											esc_html__( 'Premium RTL Wordpress Theme', 'mharty' ),
											esc_html__( 'Mharty Theme', 'mharty' ),
											true !== get_theme_mod( 'mharty_show_cr', true) ? ' style="display:none;"' : ''
												
										) : ''
									);
						echo $footer_cr_output;
						?>
					</div>
				</div>
			</div>	<!-- .container -->
		</div> <!--footer-bottom-->
	</footer> <!-- #main-footer -->

<?php endif; // ! is_page_template( 'page-template-blank.php' ) ?>
</div> <!-- #mh-main-area -->
<?php  do_action('mh_before_end_container');
   if ( '1' === get_theme_mod( 'back_to_top', '0' ) ) : ?>
   		<span class="mhc_scroll_top mh_adjust_corners"></span>
	<?php endif; ?> 
<?php if ( true === get_theme_mod( 'app_icon_sticky', false ) ){ ?>
<div class="mobile-menu-sticky-icon mh_adjust_corners">
  <button class="sandwich sandwich--collapse" type="button"
  aria-label="Menu" aria-controls="app-navigation"> <span class="sandwich-box"> <span class="sandwich-inner"></span> </span> </button>
</div>
<?php } ?>
        
</div> <!-- #page-container -->
<?php do_action('mh_after_end_container'); ?>
<?php wp_footer(); ?>
</body>
</html>