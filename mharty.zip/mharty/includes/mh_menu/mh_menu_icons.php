<?php
if ( !function_exists( 'mh_theme_icons_admin_scripts' ) ) {
  function mh_theme_icons_admin_scripts() {
    $ltr = is_rtl() ? "" : "-ltr";
    $theme_version = mh_get_theme_version();
    wp_enqueue_style( 'mh_menu_icons_style', MHARTY_THEME_ADMIN_ASSETS . 'css/menu-icons' . $ltr . '.css', array(), $theme_version );
    wp_enqueue_script( 'mh_menu_icons_script', MHARTY_THEME_ADMIN_ASSETS . 'js/menu-icons.js', array( 'jquery' ), $theme_version );
  }
}


if ( !function_exists( 'mh_theme_icons_hook_scripts' ) ) {
  function mh_theme_icons_hook_scripts() {
    add_action( 'admin_enqueue_scripts', 'mh_theme_icons_admin_scripts' );
  }
}
add_action( 'load-nav-menus.php', 'mh_theme_icons_hook_scripts' );

if ( !function_exists( 'mh_theme_icons_page' ) ) {
	function mh_theme_icons_page() { ?>

      <div class="mh_menu_icons_list">
        <?php require_once( MHARTY_THEME_DIR . '/includes/mh_menu/mh_menu_icons_list.php'); ?>
      </div>
<?php }
}

add_action( 'admin_footer-nav-menus.php', 'mh_theme_icons_page' );
add_action( 'customize_controls_print_scripts', 'mh_theme_icons_page' );