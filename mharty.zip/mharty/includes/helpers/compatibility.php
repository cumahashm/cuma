<?php
/**
 * For backward compatibility we manually add <title> tag in head
 * Title tag is automatically added for WordPress 4.1 & above via theme support
 */
if ( ! function_exists( '_wp_render_title_tag' ) ) :
	function mh_add_title_tag_before_4_4_compat() { ?>
		<title><?php wp_title(); ?></title>
<?php }
	add_action( 'wp_head', 'mh_add_title_tag_before_4_4_compat' );
endif;