<?php
/**
 * id the page where composer is used
 */
if ( ! function_exists( 'mh_core_page_resource_get_the_ID' ) ):
function mh_core_page_resource_get_the_ID() {
	static $post_id = null;

	if ( is_int( $post_id ) ) {
		return $post_id;
	}

	return $post_id = apply_filters( 'mh_core_page_resource_current_post_id', get_the_ID() );
}
endif;
/**
 * is composer active on the page?
 */
if ( ! function_exists( 'mh_composer_is_active' ) ) :
function mh_composer_is_active( $page_id = 0 ) {
	if ( 0 === $page_id ) {
		$page_id = mh_core_page_resource_get_the_ID();
	}
	return ( 'on' === get_post_meta( $page_id, '_mhc_use_composer', true ) );
}
endif;