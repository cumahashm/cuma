<?php
function mh_request_updates_data(){
  
    $data = '';
    
     if (get_site_transient( 'mh_captured_updates_data' )){
        $data = get_site_transient( 'mh_captured_updates_data' );
    
     }else{
        $key = trim( get_option( 'mharty_activation_key', '' ) );
        if ( !empty($key) ){
            $remote_url = add_query_arg( array( 'repositories' => 'all', 'get_updates' => 'get' ), apply_filters( 'mh_request_updates_data_url', 'https://mharty.com/' ) );
            $remote_request = array( 'timeout' => 15, 'body' => array( 'key' => $key ), 'user-agent' => 'WordPress;' . home_url() );
            $request = wp_remote_post( $remote_url, $remote_request );

            if ( !is_wp_error( $request ) && ( $request['response']['code'] == 200 ) ) {
                $request = json_decode( wp_remote_retrieve_body( $request ), true);

                //store for 3hrs
                set_site_transient('mh_captured_updates_data', $request, 10800);
                $data = get_site_transient( 'mh_captured_updates_data' );
            }else{
                /* If data is not an object */
                $data = new WP_Error( 'plugins_api_failed', esc_html__( 'An unknown error occurred', 'mharty' ), wp_remote_retrieve_body( $request ) );

            } 
        }
    }
    
	return $data;
}