<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' );}
/**
 * @todo add all hooks here
 * Inject content after post title
 */
if ( ! function_exists( 'mh_after_post_title' ) ) :
function mh_after_post_title(){
	do_action('mh_add_after_post_title');
}
endif;