<?php
if ( !defined( 'ABSPATH' ) ) {
  die( '-1' );
}

/**
 * Breadcrumbs Shortcode
 * [mh_breadcrumbs show_title="true" separator="/" ]
 */
function mh_breadcrumbs_shortcode( $atts ) {
  extract( shortcode_atts( array(
    'show_title' => true,
    'separator' => mh_wp_kses( _x( ' / ', 'This is the breadcrumb separator.', 'mharty' ) )
  ), $atts ) );
  return mh_breadcrumb( array(
    'show_browse' => false,
    'separator' => $separator,
    'show_home' => esc_html__( 'Home', 'mharty' ),
    'echo' => false,
    'post_taxonomy' => array(
      'post' => 'category',
    ),
    'rich_snippet' => true === get_theme_mod( 'mharty_enable_breadcrumbs_rich_snippet', true ) ? true : false,
    'show_title' => $show_title,
  ) );
}
add_shortcode( 'mh_breadcrumbs', 'mh_breadcrumbs_shortcode' );
/**
 * Search Bar Shortcode
 * [mh_search_bar placeholder="Search &hellip;" post_type="all"]
 */
function mh_search_bar_shortcode( $atts ) {
  extract( shortcode_atts( array(
    'placeholder' => esc_html__( 'Search &hellip;', 'mharty' ),
    'post_type' => 'all',
  ), $atts ) );
  
  $output = sprintf(
    '<div class="mhc_search_bar mh_search_bar_shortcode mh_adjust_corners clearfix">
				<div class="mhc_search_bar_inner">
					<form role="search" method="get" class="mhc_search_bar_form mh-hidden" action="%1$s">
						<div class="mhc_search_bar_input">
							<input id="s" type="search" class="mhc_search_bar_field mh_adjust_corners" autocomplete="off" placeholder="%2$s" value="%3$s" name="s" title="%4$s" />
							<span class="mhc_search_bar_btn">
								<button type="submit" class="button mhc_search_bar_submit"><i class="mh-icon-before"></i></button>
							</span>
							%5$s
						</div>
					</form>
				</div>
			</div> <!-- .mhc_search_bar -->',
    esc_url( home_url( '/' ) ),
    $placeholder,
    get_search_query(),
    esc_html__( 'Search for:', 'mharty' ),
    'all' !== $post_type ? sprintf(
      '<input type="hidden" value="%1$s" name="post_type" id="post_type" />', esc_attr( $post_type )
    ) : ''
  );

  return $output;

}
add_shortcode( 'mh_search_bar', 'mh_search_bar_shortcode' );
/**
 * Single Post Tags Shortcode
 * [mh_post_tags]
 */
function mh_post_tags_shortcode() {
  //works only on posts
  if ( !is_singular( array( 'post' ) ) ) return;

  ob_start();
  the_tags( '<div class="mh-tags mh-tags-shortcode"><span class="tag-links">', '', '</span></div>' );
  $output = ob_get_clean();
  return $output;
}
add_shortcode( 'mh_post_tags', 'mh_post_tags_shortcode' );

/**
 * Single Related Posts Shortcode
 * [mh_post_related]
 * see mh_function.php
 */