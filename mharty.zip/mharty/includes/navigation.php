<div class="pagination cf">
	<div class="alignright"><?php next_posts_link(esc_html__('&laquo; Older Entries','mharty')) ?></div>
	<div class="alignleft"><?php previous_posts_link(esc_html__('Next Entries &raquo;', 'mharty')) ?></div>
</div>