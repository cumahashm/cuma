<ul class="mh-social-icons">
<?php if ( true === get_theme_mod( 'mharty_show_twitter_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-twitter">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_twitter_url', '#' ) ); ?>" class="icon">
			<span>Twitter</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_facebook_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-facebook">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_facebook_url', '#' ) ); ?>" class="icon">
			<span>Facebook</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_instagram_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-instagram">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_instagram_url', '#' ) ); ?>" class="icon">
			<span>Instagram</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_youtube_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-youtube">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_youtube_url', '#' ) ); ?>" class="icon">
			<span>YouTube</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_linkedin_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-linkedin">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_linkedin_url', '#' ) ); ?>" class="icon">
			<span>YouTube</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_behance_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-behance">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_behance_url', '#' ) ); ?>" class="icon">
			<span>Behance</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_dribbble_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-dribbble">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_dribbble_url', '#' ) ); ?>" class="icon">
			<span>Dribbble</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_flickr_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-flickr">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_flickr_url', '#' ) ); ?>" class="icon">
			<span>Flickr</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_skype_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-skype">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_skype_url', '#' ) ); ?>" class="icon">
			<span>Skype</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_soundcloud_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-soundcloud">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_soundcloud_url', '#' ) ); ?>" class="icon">
			<span>SoundCloud</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_telegram_icon', true ) ) : ?>
	<li class="mh-social-icon mh-social-telegram">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_telegram_url', '#' ) ); ?>" class="icon">
			<span>Telegram Broadcast</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_mixlr_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-mixlr">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_mixlr_url', '#' ) ); ?>" class="icon">
			<span>Mixlr</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_periscope_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-periscope">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_periscope_url', '#' ) ); ?>" class="icon">
			<span>Periscope</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_younow_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-younow">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_younow_url', '#' ) ); ?>" class="icon">
			<span>YouNow</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_snapchat_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-snapchat">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_snapchat_url', '#' ) ); ?>" class="icon">
			<span>Snapchat</span>
		</a>
	</li>
<?php endif; ?>

<?php if ( true === get_theme_mod( 'mharty_show_tripadvisor_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-tripadvisor">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_tripadvisor_url', '#' ) ); ?>" class="icon">
			<span>TripAdvisor</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_pinterest_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-pinterest">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_pinterest_url', '#' ) ); ?>" class="icon">
			<span>Pinterest</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_whatsapp_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-whatsapp">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_whatsapp_url', '#' ) ); ?>" class="icon">
			<span>WhatsApp</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_slack_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-slack">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_slack_url', '#' ) ); ?>" class="icon">
			<span>Slack</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_github_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-github">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_github_url', '#' ) ); ?>" class="icon">
			<span>Github</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_wordpress_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-wordpress">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_wordpress_url', '#' ) ); ?>" class="icon">
			<span>WordPress</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_tiktok_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-tiktok">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_tiktok_url', '#' ) ); ?>" class="icon">
			<span>TikTok</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_clubhouse_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-clubhouse">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_clubhouse_url', '#' ) ); ?>" class="icon">
			<span>Clubhouse</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_zoom_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-zoom">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_zoom_url', '#' ) ); ?>" class="icon">
			<span>Zoom</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_beeto_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-beeto">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_beeto_url', '#' ) ); ?>" class="icon">
			<span>Beeto</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_apple_podcast_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-apple-podcast">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_apple_podcast_url', '#' ) ); ?>" class="icon">
			<span>Apple Podcast</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_google_podcast_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-google-podcast">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_google_podcast_url', '#' ) ); ?>" class="icon">
			<span>Apple Podcast</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_spotify_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-spotify">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_spotify_url', '#' ) ); ?>" class="icon">
			<span>Apple Podcast</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_podchaser_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-podchaser">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_podchaser_url', '#' ) ); ?>" class="icon">
			<span>Apple Podcast</span>
		</a>
	</li>
<?php endif; ?>
  
<?php if ( true === get_theme_mod( 'mharty_show_rss_icon', false ) ) : ?>
<?php
	$mh_rss_url = '' !== get_theme_mod( 'mharty_rss_url' )
		? get_theme_mod( 'mharty_rss_url' )
		: get_bloginfo( 'rss2_url' );
?>
	<li class="mh-social-icon mh-social-rss">
		<a target="_blank" href="<?php echo esc_url( $mh_rss_url ); ?>" class="icon">
			<span>RSS</span>
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_custom_1_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-custom-1">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_custom_1_icon_url', '#' ) ); ?>" class="icon">
		</a>
	</li>
<?php endif; ?>
<?php if ( true === get_theme_mod( 'mharty_show_custom_2_icon', false ) ) : ?>
	<li class="mh-social-icon mh-social-custom-2">
		<a target="_blank" href="<?php echo esc_url( get_theme_mod( 'mharty_custom_2_icon_url', '#' ) ); ?>" class="icon">
		</a>
	</li>
<?php endif; ?>
</ul>