<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Checkbox sanitization callback
 */
function mh_sanitize_checkbox( $checked ) {
	// Boolean check.
	return ( ( isset( $checked ) && true == $checked ) ? true : false );
}
