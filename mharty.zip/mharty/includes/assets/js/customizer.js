var clearpath = mh_customizer_settigs.clearpath;
(function($){
    $(document).ready(function () {

        $( 'div#customize-info' ).replaceWith( '<div class="mh_customizer-customizer"></div>' );
        
        //controls
        $('.mh_customizer_reset_slider').click(function () {
            var $this_input = $(this).closest('label').find('input'),
                input_name = $this_input.data('customize-setting-link'),
                input_default = $this_input.data('reset_value');

            $this_input.val(input_default);
            $this_input.change();
        });


        $('input[type=range]').on('mousedown', function () {
            var $range = $(this),
                $range_input = $range.parent().children('.mh-customizer-range-input');

             $range_input.val($(this).val());

            $(this).mousemove(function () {
                $range_input.val($(this).val());
            });
        });

        var mh_range_input_number_timeout;

        function mh_autocorrect_range_input_number(input_number, timeout) {
            $range_input = input_number,
                $range = $range_input.parent().find('input[type="range"]'),
                value = parseFloat($range_input.val()),
                reset = parseFloat($range.attr('data-reset_value')),
                step = parseFloat($range_input.attr('step')),
                min = parseFloat($range_input.attr('min')),
                max = parseFloat($range_input.attr('max'));

            clearTimeout(mh_range_input_number_timeout);

            mh_range_input_number_timeout = setTimeout(function () {
                if (isNaN(value)) {
                    $range_input.val(reset);
                    $range.val(reset).trigger('change');
                    return;
                }

                if (step >= 1 && value % 1 !== 0) {
                    value = Math.round(value);
                    $range_input.val(value);
                    $range.val(value);
                }

                if (value > max) {
                    $range_input.val(max);
                    $range.val(max).trigger('change');
                }

                if (value < min) {
                    $range_input.val(min);
                    $range.val(min).trigger('change');
                }
            }, timeout);

            $range.val(value).trigger('change');
        }

        $('input.mh-customizer-range-input').on('change keyup', function () {
            mh_autocorrect_range_input_number($(this), 1000);
        }).on('focusout', function () {
            mh_autocorrect_range_input_number($(this), 0);
        });



        /*
         * Script run inside a Customizer control sidebar
         *
         * Enable / disable the control title by toggeling its .disabled-control-title style class on or off.
         */
        wp.customize.bind('ready', function () { // Ready?

            var customize = this; // Customize object alias.

            //get the toggle controls
            var toggleControls = $('.customize-switch-label').parent();

            var toggleControlIds = [];

            //Segment in the id of the control that is added by wordpress, but not needed for our purpose
            var idSegment = "customize-control-";

            //fill the id array
            for (var control of toggleControls) {
                //remove the segment from the control id
                var controlId = control.id.substring(idSegment.length, control.id.length);
                toggleControlIds.push(controlId);
            }

            $.each(toggleControlIds, function (index, control_name) {
                customize(control_name, function (value) {
                    var controlTitle = customize.control(control_name).container.find('.customize-control-title'); // Get control  title.
                    // 1. On loading.
                    controlTitle.toggleClass('disabled-control-title', !value.get());
                    // 2. Binding to value change.
                    value.bind(function (to) {
                        controlTitle.toggleClass('disabled-control-title', !value.get());
                    });
                });
            });
        });
        //Multiple checkbox Control
        $('.customize-control-multiple-checkbox input[type="checkbox"]').on(
            'change',
            function () {

                checkbox_values = $(this).parents('.customize-control').find('input[type="checkbox"]:checked').map(
                    function () {
                        return this.value;
                    }
                ).get().join(',');

                $(this).parents('.customize-control').find('input[type="hidden"]').val(checkbox_values).trigger('change');
            }
        );

        $('.customize-control-multiple-checkbox-image input[type="checkbox"]').on(
            'change',
            function () {

                checkbox_values = $(this).parents('.customize-control').find('input[type="checkbox"]:checked').map(
                    function () {
                        return this.value;
                    }
                ).get().join(',');

                $(this).parents('.customize-control').find('input[type="hidden"]').val(checkbox_values).trigger('change');
            }
        );
        
        //postinfo checkbox
         $('.customize-control-multiple-checkbox-image input:checkbox:not([safari])').checkbox();
		 $('.customize-control-multiple-checkbox-image input[safari]:checkbox').checkbox({cls:'jquery-safari-checkbox'});
		 $('.customize-control-multiple-checkbox-image input:radio').checkbox();
        
        //description tooltip
        $(".mh-setting-description-mark").click(function(){
			var box_title = $(this).siblings(".mh-setting-description-title").html();
			var box_content = $(this).siblings(".mh-setting-description").html();

			$('body').append("<div id='mh-popup-box'><div class='box-desc'><div class='box-desc-top'>"+ box_title+"</div><div class='box-desc-content'>"+box_content+"<div class='lightboxclose'></div></div></div></div>");

			mh_panel_popup( $( '.mh-setting-description' ) );

			$( '.lightboxclose' ).click( function() {
				mh_panel_popup_close( $( '#mh-popup-box' ) );
			});
		});
        
        $(".mh-menu-icon-button, .mh-menu-icon-show").each(function (index) {
            var $this_el = $(this),
                $closest_field = $this_el.closest('label').find('.mh-menu-icon-field'),
                $closest_show = $this_el.closest('label').find('.mh-menu-icon-show'),
                $closest_reset = $this_el.closest('label').find('.mh-menu-icon-button-reset'),
                box_content = $(".mh_menu_icons_list").html(),
                $parent = $(this).parent('label');

            $this_el.on("click", function () {
                
                $('body').append("<div id='mh_menu_icons_box'><div class='mh_menu_icons_box_inner'><div class='mh_menu_icons_box_content'>" + box_content + "<div class='mh_menu_icons_box_close'></div></div></div></div>");
                
                mh_panel_popup($('.mh_menu_icons_box_inner'));
                
                $('.mh_menu_icons_box_close').click(function () {
                    mh_panel_popup_close($('#mh_menu_icons_box'));
                });
                
                $('.glyph').on("click", function () {
                     var $item = $(this).find('input.unit');
                         $closest_field.val( $item.val() );
                         $closest_show.html( '<em>&#x' + $item.val() + ';</em>' );
                         $closest_field.change();
                         mh_panel_popup_close($('#mh_menu_icons_box'));
                         $this_el.removeClass('mh-menu-icon-button');
                });
            });
            
            $closest_reset.on("click", function () {
                $closest_field.val( '' );
                $closest_show.html( '' );
                $closest_field.change();
                $this_el.addClass('mh-menu-icon-button');
            });
            
        });
        
        //end controls
    }); //.ready

    function mh_panel_popup_close($overlay, no_overlay_remove) {
        var $popup_container = $overlay;

        // add class to apply the closing animation to popup
        $popup_container.addClass('mhc_popup_closing');

        //remove the popup with overlay when animation complete
        setTimeout(function () {
            if ('no_remove' !== no_overlay_remove) {
                $popup_container.remove();
            }
        }, 200);
    }

    function mh_panel_popup($popup) {
        var popup_height = $popup.outerHeight(),
            popup_height_adjustment = 0 - (popup_height / 2);

        $popup.css({
            top: '50%',
            bottom: 'auto',
            marginTop: popup_height_adjustment
        });
    }


    //reset
    var $container = $('#customize-header-actions');

    var $button = $('<a id="mh-customizer-reset" class="mh-customizer-reset" href="#"></a>')
        .attr('title', mh_customizer_settigs.reset);

    $button.on('click', function (event) {
        event.preventDefault();

        var data = {
            wp_customize: 'on',
            action: 'customizer_reset',
            nonce: mh_customizer_settigs.nonce.reset
        };

        var r = confirm(mh_customizer_settigs.confirm);

        if (!r) return;

        $button.attr('disabled', 'disabled');

        $.post(ajaxurl, data, function () {
            wp.customize.state('saved').set(true);
            location.reload();
        });
    });

    $container.append($button);

})(jQuery);